"""
Smart Test Plan Compliance Checker - Optimized Source Package
"""

__version__ = "2.0.0"
__author__ = "Smart Compliance Team"
__description__ = "Optimized compliance checking for test plans and reports"
