"""
Optimized Compliance Package
"""

from .base_checker import BaseComplianceChecker, ComplianceResult
from .docx_compliance import OptimizedDocxComplianceChecker, ComplianceChecker
from .pptx_compliance import OptimizedPptxComplianceChecker, TestReportComplianceChecker

__all__ = [
    'BaseComplianceChecker',
    'ComplianceResult',
    'OptimizedDocxComplianceChecker',
    'ComplianceChecker',
    'OptimizedPptxComplianceChecker',
    'TestReportComplianceChecker'
]
