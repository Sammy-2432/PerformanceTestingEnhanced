"""
Optimized Components Package
"""

from .app_core import OptimizedComplianceApp

__all__ = ['OptimizedComplianceApp']
