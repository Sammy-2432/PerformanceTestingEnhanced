#!/usr/bin/env python3
"""
Quick System Test - Verify all components are working
"""

import sys
import os

# Add parent directory to path so we can import src modules
parent_dir = os.path.dirname(os.path.dirname(__file__))
sys.path.insert(0, parent_dir)

def test_imports():
    """Test all module imports"""
    print("🧪 Testing imports...")
    
    try:
        # Test core modules from src/
        from src.utils.excel_reader import ExcelReader
        print("✅ ExcelReader imported successfully")
        
        from src.analyzers.docx_analyzer import OptimizedDocxAnalyzer
        print("✅ DocxAnalyzer imported successfully")
        
        from src.compliance.docx_compliance import OptimizedDocxComplianceChecker
        print("✅ ComplianceChecker imported successfully")
        
        from src.analyzers.ppt_analyzer import OptimizedPowerPointAnalyzer
        print("✅ PowerPointAnalyzer imported successfully")
        
        from src.compliance.pptx_compliance import OptimizedPptxComplianceChecker
        print("✅ TestReportComplianceChecker imported successfully")
        
        import src.config as config
        print("✅ Config imported successfully")
        
        # Test Streamlit app
        import main
        print("✅ Main app imported successfully")
        
        return True
        
    except Exception as e:
        print(f"❌ Import error: {str(e)}")
        return False

def test_excel_reader():
    """Test ExcelReader functionality"""
    print("\n📊 Testing ExcelReader...")
    
    try:
        from src.utils.excel_reader import ExcelReader
        
        # Test with existing file
        excel_path = "data/sample_project_data.xlsx"
        if os.path.exists(excel_path):
            reader = ExcelReader(excel_path)
            if reader.load_data():
                print("✅ Excel data loaded successfully")
                
                # Test methods
                releases = reader.get_releases()
                print(f"✅ Found {len(releases)} releases: {releases}")
                
                if releases:
                    projects = reader.get_projects_by_release(releases[0])
                    print(f"✅ Found {len(projects)} projects for {releases[0]}")
                
                return True
            else:
                print("❌ Failed to load Excel data")
                return False
        else:
            print(f"⚠️ Excel file not found: {excel_path}")
            return False
            
    except Exception as e:
        print(f"❌ ExcelReader error: {str(e)}")
        return False

def test_document_analysis():
    """Test document analysis functionality"""
    print("\n📄 Testing Document Analysis...")
    
    try:
        # Check if sample document exists
        doc_path = "data/Sample_Test_Plan_Compliant.docx"
        if os.path.exists(doc_path):
            print(f"✅ Found test document: {doc_path}")
            
            # Test DOCX analysis
            from src.analyzers.docx_analyzer import OptimizedDocxAnalyzer as DocxAnalyzer
            with open(doc_path, 'rb') as f:
                file_content = f.read()
            analyzer = DocxAnalyzer(file_content)
            data = analyzer.analyze()
            print("✅ DOCX analysis completed")
            print(f"   - First page data: {bool(data.get('first_page_data'))}")
            print(f"   - Footer data: {bool(data.get('footer_data'))}")
            print(f"   - TOC found: {data.get('table_of_contents', {}).get('toc_found', False)}")
            
            return True
        else:
            return False
            
    except Exception as e:
        print(f"❌ Document analysis error: {str(e)}")
        return False

def test_compliance_checking():
    """Test compliance checking functionality"""
    print("\n🔍 Testing Compliance Checking...")
    
    try:
        from src.utils.excel_reader import ExcelReader
        from src.analyzers.docx_analyzer import DocxAnalyzer
        from src.compliance.docx_compliance import OptimizedDocxComplianceChecker as ComplianceChecker
        
        # Load test data
        excel_path = "data/sample_project_data.xlsx" 
        doc_path = "data/Sample_Test_Plan_Compliant.docx"
        
        if os.path.exists(excel_path) and os.path.exists(doc_path):
            # Load Excel data
            reader = ExcelReader(excel_path)
            if not reader.load_data():
                print("❌ Failed to load Excel data for compliance test")
                return False
            
            # Analyze document
            with open(doc_path, 'rb') as f:
                file_content = f.read()
            analyzer = DocxAnalyzer(file_content)
            docx_data = analyzer.analyze()
            
            # Run compliance checks
            checker = ComplianceChecker(reader.data, docx_data)
            results = checker.run_all_checks()
            
            print("✅ Compliance checking completed")
            overall_stats = results.get('overall_statistics', {})
            print(f"   - Overall score: {overall_stats.get('overall_score', 0)}")
            print(f"   - Checks passed: {overall_stats.get('passed_checks', 0)}/{overall_stats.get('total_checks', 0)}")
            print(f"   - Compliance level: {overall_stats.get('compliance_level', 'Unknown')}")
            
            return True
        else:
            print("⚠️ Missing test files for compliance check")
            return False
            
    except Exception as e:
        print(f"❌ Compliance checking error: {str(e)}")
        return False

def test_powerpoint_modules():
    """Test PowerPoint-related modules"""
    print("\n📊 Testing PowerPoint Modules...")
    
    try:
        from src.analyzers.ppt_analyzer import OptimizedPowerPointAnalyzer
        from src.compliance.pptx_compliance import OptimizedPptxComplianceChecker as TestReportComplianceChecker
        
        # Test instantiation (without actual file)
        sample_data = {'test': 'data'}
        checker = TestReportComplianceChecker(sample_data, sample_data)
        print("✅ TestReportComplianceChecker instantiated successfully")
        
        return True
        
    except Exception as e:
        print(f"❌ PowerPoint modules error: {str(e)}")
        return False

def generate_system_report():
    """Generate a comprehensive system report"""
    print("🚀 SMART TEST PLAN COMPLIANCE CHECKER - SYSTEM TEST")
    print("=" * 60)
    
    all_tests_passed = True
    
    # Run all tests
    tests = [
        ("Module Imports", test_imports),
        ("Excel Reader", test_excel_reader), 
        ("Document Analysis", test_document_analysis),
        ("Compliance Checking", test_compliance_checking),
        ("PowerPoint Modules", test_powerpoint_modules)
    ]
    
    results = {}
    for test_name, test_func in tests:
        print(f"\n{'=' * 20}")
        result = test_func()
        results[test_name] = result
        if not result:
            all_tests_passed = False
    
    # Summary
    print(f"\n{'=' * 60}")
    print("📋 TEST SUMMARY")
    print("=" * 60)
    
    for test_name, result in results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{test_name:.<30} {status}")
    
    print(f"\n🎯 OVERALL SYSTEM STATUS: {'✅ ALL SYSTEMS GO!' if all_tests_passed else '⚠️ ISSUES DETECTED'}")
    
    if all_tests_passed:
        print("\n🚀 Ready to run: streamlit run main.py")
    else:
        print("\n🔧 Please fix the issues above before running the application")
    
    return all_tests_passed

if __name__ == "__main__":
    generate_system_report()
